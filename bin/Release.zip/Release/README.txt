Make sure the folder is INSIDE the Chatlogs folder
Make sure you have .NET Core distributables https://dotnet.microsoft.com/en-us/download/dotnet/3.1

if you dont have it choose the one you need:

Windows:
https://dotnet.microsoft.com/en-us/download/dotnet/thank-you/runtime-3.1.27-windows-x64-installer
https://dotnet.microsoft.com/en-us/download/dotnet/thank-you/runtime-3.1.27-windows-x86-installer
Mac:

https://dotnet.microsoft.com/en-us/download/dotnet/thank-you/runtime-3.1.27-macos-x64-installer

Linux:
https://docs.microsoft.com/en-us/dotnet/core/install/linux?WT.mc_id=dotnet-35129-website


All: (Haven't actually used this so idk)

https://dotnet.microsoft.com/en-us/download/dotnet/scripts 

Release --> netcoreapp3.1 --> run DiscordGaurdUpdates.exe 